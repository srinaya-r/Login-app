const API = "http://localhost:8000/api"; // backend address
const $ = (id) => document.getElementById(id);
const VIEWS = ["login", "register", "forgot-pass", "forgot-user", "dashboard"];
const ROLE_LABEL = { super_admin: "Super Admin", admin: "Admin", user: "User" };
let me = null;

function show(view) {
  VIEWS.forEach((v) => ($("view-" + v).hidden = v !== view));
  setMsg("");
}

function setMsg(text, ok = false) {
  const m = $("msg");
  m.textContent = text; // textContent (not innerHTML) => no XSS from server/user text
  m.className = ok ? "ok" : "err";
  m.hidden = !text;
}

function errText(data) {
  if (typeof data.detail === "string") return data.detail;
  if (Array.isArray(data.detail)) return data.detail.map((d) => d.msg.replace("Value error, ", "")).join(". ");
  return "Something went wrong";
}

async function api(path, method = "GET", body) {
  const headers = { "Content-Type": "application/json" };
  const token = sessionStorage.getItem("token");
  if (token) headers.Authorization = "Bearer " + token;
  let res;
  try {
    res = await fetch(API + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch {
    throw new Error("Cannot reach the server. Is the backend running?");
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && token && path !== "/login") logout("Session expired. Please log in again.");
    throw new Error(errText(data));
  }
  return data;
}

function onSubmit(id, handler) {
  $(id).addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = e.submitter;
    btn.disabled = true;
    try {
      await handler(Object.fromEntries(new FormData(e.target)), e.target);
    } catch (err) {
      setMsg(err.message);
    } finally {
      btn.disabled = false;
    }
  });
}

document.querySelectorAll("[data-go]").forEach((a) =>
  a.addEventListener("click", (e) => { e.preventDefault(); show(a.dataset.go); })
);

// ----- Auth flows -----
onSubmit("f-login", async (d, form) => {
  const res = await api("/login", "POST", d);
  sessionStorage.setItem("token", res.token); // cleared when the tab closes
  form.reset();
  await loadDashboard();
});

onSubmit("f-register", async (d, form) => {
  const res = await api("/register", "POST", d);
  form.reset();
  show("login");
  setMsg(res.message, true);
});

let resetEmail = "", userEmail = "";

onSubmit("f-fp1", async (d, form) => {
  resetEmail = d.email;
  const res = await api("/forgot-password", "POST", d);
  $("f-fp2").hidden = false;
  setMsg(res.message, true);
});
onSubmit("f-fp2", async (d, form) => {
  const res = await api("/reset-password", "POST", { email: resetEmail, ...d });
  form.reset(); $("f-fp1").reset(); $("f-fp2").hidden = true;
  show("login");
  setMsg(res.message, true);
});

onSubmit("f-fu1", async (d) => {
  userEmail = d.email;
  const res = await api("/forgot-username", "POST", d);
  $("f-fu2").hidden = false;
  setMsg(res.message, true);
});
onSubmit("f-fu2", async (d, form) => {
  const res = await api("/verify-username-code", "POST", { email: userEmail, ...d });
  form.reset(); $("f-fu1").reset(); $("f-fu2").hidden = true;
  show("login");
  setMsg("Your username is: " + res.username, true);
});

onSubmit("f-change", async (d, form) => {
  const res = await api("/change-password", "POST", d);
  sessionStorage.setItem("token", res.token); // old tokens were invalidated server-side
  form.reset();
  setMsg(res.message, true);
});

$("logout").addEventListener("click", () => logout());

function logout(message = "") {
  sessionStorage.removeItem("token");
  me = null;
  show("login");
  if (message) setMsg(message);
}

// ----- Dashboard -----
async function loadDashboard() {
  me = await api("/me");
  $("greeting").textContent = `Hi ${me.first_name} ${me.last_name}`;
  $("role").textContent = ROLE_LABEL[me.role];
  $("age").textContent = me.age;
  show("dashboard");
  const isStaff = me.role === "admin" || me.role === "super_admin";
  $("admin-panel").hidden = !isStaff;
  if (isStaff) await loadUsers();
}

async function loadUsers() {
  const users = await api("/users");
  const tbody = document.querySelector("#users tbody");
  tbody.replaceChildren();
  for (const u of users) {
    const tr = document.createElement("tr");
    for (const val of [u.id, u.username, `${u.first_name} ${u.last_name}`, u.email]) {
      const td = document.createElement("td");
      td.textContent = val;
      tr.appendChild(td);
    }
    const roleTd = document.createElement("td");
    if (me.role === "super_admin" && u.id !== me.id) {
      const sel = document.createElement("select");
      for (const r of Object.keys(ROLE_LABEL)) {
        const o = new Option(ROLE_LABEL[r], r, false, r === u.role);
        sel.appendChild(o);
      }
      sel.addEventListener("change", async () => {
        try {
          await api(`/users/${u.id}/role`, "PATCH", { role: sel.value });
          setMsg(`${u.username} is now ${ROLE_LABEL[sel.value]}`, true);
        } catch (err) { setMsg(err.message); await loadUsers(); }
      });
      roleTd.appendChild(sel);
    } else {
      roleTd.textContent = ROLE_LABEL[u.role];
    }
    tr.appendChild(roleTd);
    tbody.appendChild(tr);
  }
}

// ----- Start: resume session if a token exists -----
if (sessionStorage.getItem("token")) loadDashboard().catch(() => logout());
else show("login");
