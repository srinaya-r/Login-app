# Auth demo (FastAPI + plain HTML/JS)

## Run backend (terminal 1)
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env        # then set SECRET_KEY (see comment inside)
uvicorn main:app --reload --port 8000

## Run frontend (terminal 2)
cd frontend
python -m http.server 5500
# open http://localhost:5500

Login as the super admin from .env (default: superadmin / ChangeMe123).
Leave SMTP_HOST empty and reset codes print in the backend terminal.
API docs: http://localhost:8000/docs
