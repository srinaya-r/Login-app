import os
import re
import secrets
import sqlite3
import hmac
import hashlib
import smtplib
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from email.message import EmailMessage

import bcrypt
import jwt
from dotenv import load_dotenv
from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, EmailStr, Field, field_validator

load_dotenv()

# ---------- Config ----------
SECRET_KEY = os.getenv("SECRET_KEY", "")
if len(SECRET_KEY) < 32:
    raise RuntimeError("Set SECRET_KEY (32+ chars) in backend/.env")
DB_PATH = os.getenv("DB_PATH", "app.db")
FRONTEND_ORIGIN = os.getenv("FRONTEND_ORIGIN", "http://localhost:5500")
SMTP_HOST = os.getenv("SMTP_HOST", "")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASS = os.getenv("SMTP_PASS", "")
SMTP_FROM = os.getenv("SMTP_FROM", SMTP_USER)

TOKEN_MINUTES = 30
CODE_MINUTES = 10
MAX_CODE_ATTEMPTS = 5
MAX_LOGIN_FAILS = 5
LOCK_MINUTES = 15
ROLES = ("super_admin", "admin", "user")

app = FastAPI(title="Auth Demo API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[FRONTEND_ORIGIN],
    allow_methods=["GET", "POST", "PATCH"],
    allow_headers=["Authorization", "Content-Type"],
)


# ---------- Database ----------
@contextmanager
def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    finally:
        c.close()


def now():
    return datetime.now(timezone.utc)


def hash_pw(pw: str) -> str:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()


def check_pw(pw: str, hashed: str) -> bool:
    return bcrypt.checkpw(pw.encode(), hashed.encode())


DUMMY_HASH = hash_pw("dummy-password-for-timing")


@app.on_event("startup")
def init_db():
    with conn() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                dob TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'user',
                token_version INTEGER NOT NULL DEFAULT 0,
                failed_attempts INTEGER NOT NULL DEFAULT 0,
                locked_until TEXT
            );
            CREATE TABLE IF NOT EXISTS codes (
                email TEXT NOT NULL,
                purpose TEXT NOT NULL,
                code_hash TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                created_at TEXT NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (email, purpose)
            );
            """
        )
        # Seed the first super admin from .env (nobody can self-register as one)
        u, e, p = (os.getenv(k, "") for k in ("SUPERADMIN_USERNAME", "SUPERADMIN_EMAIL", "SUPERADMIN_PASSWORD"))
        has_sa = c.execute("SELECT 1 FROM users WHERE role='super_admin'").fetchone()
        if u and e and p and not has_sa:
            c.execute(
                "INSERT INTO users (username,email,first_name,last_name,dob,password_hash,role) "
                "VALUES (?,?,?,?,?,?, 'super_admin')",
                (u, e, "Super", "Admin", "1990-01-01", hash_pw(p)),
            )


# ---------- Validation ----------
def strong_password(pw: str) -> str:
    if len(pw) < 8 or len(pw) > 72:  # bcrypt only uses first 72 bytes
        raise ValueError("Password must be 8-72 characters")
    if not (re.search(r"[a-z]", pw) and re.search(r"[A-Z]", pw) and re.search(r"\d", pw)):
        raise ValueError("Password needs upper case, lower case and a number")
    return pw


def age_from(dob_str: str) -> int:
    d = date.fromisoformat(dob_str)
    t = date.today()
    return t.year - d.year - ((t.month, t.day) < (d.month, d.day))


class RegisterIn(BaseModel):
    username: str = Field(min_length=3, max_length=30, pattern=r"^[A-Za-z0-9_.]+$")
    email: EmailStr
    first_name: str = Field(min_length=1, max_length=50)
    last_name: str = Field(min_length=1, max_length=50)
    dob: date
    password: str

    _pw = field_validator("password")(strong_password)

    @field_validator("dob")
    @classmethod
    def valid_dob(cls, v):
        age = age_from(v.isoformat())
        if age < 13 or age > 120:
            raise ValueError("Age must be between 13 and 120")
        return v


class LoginIn(BaseModel):
    identifier: str = Field(min_length=1, max_length=254)  # username OR email
    password: str = Field(min_length=1, max_length=200)


class ChangePwIn(BaseModel):
    old_password: str
    new_password: str
    _pw = field_validator("new_password")(strong_password)


class EmailIn(BaseModel):
    email: EmailStr


class ResetIn(BaseModel):
    email: EmailStr
    code: str = Field(pattern=r"^\d{6}$")
    new_password: str
    _pw = field_validator("new_password")(strong_password)


class CodeIn(BaseModel):
    email: EmailStr
    code: str = Field(pattern=r"^\d{6}$")


class RoleIn(BaseModel):
    role: str

    @field_validator("role")
    @classmethod
    def valid_role(cls, v):
        if v not in ROLES:
            raise ValueError("Invalid role")
        return v


# ---------- Email + codes ----------
def send_email(to: str, subject: str, body: str):
    if not SMTP_HOST:  # dev fallback: print instead of sending
        print(f"\n[DEV EMAIL -> {to}]\nSubject: {subject}\n{body}\n")
        return
    try:
        msg = EmailMessage()
        msg["From"], msg["To"], msg["Subject"] = SMTP_FROM, to, subject
        msg.set_content(body)
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=15) as s:
            s.starttls()
            s.login(SMTP_USER, SMTP_PASS)
            s.send_message(msg)
    except Exception as exc:  # never leak SMTP errors to the client
        print("Email send failed:", exc)


def hash_code(email: str, purpose: str, code: str) -> str:
    return hmac.new(SECRET_KEY.encode(), f"{email.lower()}|{purpose}|{code}".encode(), hashlib.sha256).hexdigest()


def issue_code(email: str, purpose: str):
    """Returns a code, or None if one was issued in the last 60s (anti-spam)."""
    with conn() as c:
        row = c.execute("SELECT created_at FROM codes WHERE email=? AND purpose=?", (email, purpose)).fetchone()
        if row and now() - datetime.fromisoformat(row["created_at"]) < timedelta(seconds=60):
            return None
        code = f"{secrets.randbelow(10**6):06d}"
        c.execute(
            "INSERT OR REPLACE INTO codes VALUES (?,?,?,?,?,0)",
            (email.lower(), purpose, hash_code(email, purpose, code),
             (now() + timedelta(minutes=CODE_MINUTES)).isoformat(), now().isoformat()),
        )
        return code


def consume_code(email: str, purpose: str, code: str) -> bool:
    with conn() as c:
        row = c.execute("SELECT * FROM codes WHERE email=? AND purpose=?", (email.lower(), purpose)).fetchone()
        if not row or datetime.fromisoformat(row["expires_at"]) < now() or row["attempts"] >= MAX_CODE_ATTEMPTS:
            return False
        c.execute("UPDATE codes SET attempts=attempts+1 WHERE email=? AND purpose=?", (email.lower(), purpose))
        if hmac.compare_digest(row["code_hash"], hash_code(email, purpose, code)):
            c.execute("DELETE FROM codes WHERE email=? AND purpose=?", (email.lower(), purpose))  # one-time use
            return True
        return False


# ---------- Auth helpers ----------
bearer = HTTPBearer(auto_error=False)


def make_token(user) -> str:
    payload = {
        "sub": str(user["id"]),
        "tv": user["token_version"],
        "exp": now() + timedelta(minutes=TOKEN_MINUTES),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")


def current_user(cred: HTTPAuthorizationCredentials = Depends(bearer)):
    err = HTTPException(401, "Not authenticated")
    if not cred:
        raise err
    try:
        payload = jwt.decode(cred.credentials, SECRET_KEY, algorithms=["HS256"])
    except jwt.PyJWTError:
        raise err
    with conn() as c:
        user = c.execute("SELECT * FROM users WHERE id=?", (payload["sub"],)).fetchone()
    # token_version changes on password change/reset -> old tokens die
    if not user or user["token_version"] != payload["tv"]:
        raise err
    return user


def require_roles(*roles):
    def dep(user=Depends(current_user)):
        if user["role"] not in roles:
            raise HTTPException(403, "You do not have permission")
        return user
    return dep


def public(user) -> dict:
    return {
        "id": user["id"], "username": user["username"], "email": user["email"],
        "first_name": user["first_name"], "last_name": user["last_name"],
        "role": user["role"], "age": age_from(user["dob"]),
    }


# ---------- Routes ----------
@app.post("/api/register", status_code=201)
def register(data: RegisterIn):
    # role is NOT accepted from the client: every signup is a plain 'user'
    try:
        with conn() as c:
            c.execute(
                "INSERT INTO users (username,email,first_name,last_name,dob,password_hash,role) "
                "VALUES (?,?,?,?,?,?, 'user')",
                (data.username, data.email, data.first_name.strip(), data.last_name.strip(),
                 data.dob.isoformat(), hash_pw(data.password)),
            )
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Username or email is already registered")
    return {"message": "Account created. You can log in now."}


@app.post("/api/login")
def login(data: LoginIn):
    with conn() as c:
        user = c.execute(
            "SELECT * FROM users WHERE username=? OR email=?", (data.identifier, data.identifier)
        ).fetchone()
        generic = HTTPException(401, "Invalid credentials")
        if not user:
            check_pw(data.password, DUMMY_HASH)  # keeps timing similar
            raise generic
        if user["locked_until"] and datetime.fromisoformat(user["locked_until"]) > now():
            raise HTTPException(429, "Too many failed attempts. Try again later.")
        if not check_pw(data.password, user["password_hash"]):
            fails = user["failed_attempts"] + 1
            lock = (now() + timedelta(minutes=LOCK_MINUTES)).isoformat() if fails >= MAX_LOGIN_FAILS else None
            c.execute("UPDATE users SET failed_attempts=?, locked_until=? WHERE id=?",
                      (0 if lock else fails, lock, user["id"]))
            c.commit()
            raise generic
        c.execute("UPDATE users SET failed_attempts=0, locked_until=NULL WHERE id=?", (user["id"],))
    return {"token": make_token(user), "user": public(user)}


@app.get("/api/me")
def me(user=Depends(current_user)):
    return public(user)


@app.post("/api/change-password")
def change_password(data: ChangePwIn, user=Depends(current_user)):
    if not check_pw(data.old_password, user["password_hash"]):
        raise HTTPException(400, "Current password is incorrect")
    with conn() as c:
        c.execute("UPDATE users SET password_hash=?, token_version=token_version+1 WHERE id=?",
                  (hash_pw(data.new_password), user["id"]))
        fresh = c.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
    return {"message": "Password changed", "token": make_token(fresh)}  # other sessions are logged out


GENERIC = {"message": "If that email is registered, a code has been sent."}


@app.post("/api/forgot-password")
def forgot_password(data: EmailIn, bg: BackgroundTasks):
    with conn() as c:
        user = c.execute("SELECT 1 FROM users WHERE email=?", (data.email,)).fetchone()
    if user and (code := issue_code(data.email, "reset")):
        bg.add_task(send_email, data.email, "Your password reset code",
                    f"Your code is {code}. It expires in {CODE_MINUTES} minutes.\n"
                    "If you did not request this, ignore this email.")
    return GENERIC  # same answer whether or not the email exists


@app.post("/api/reset-password")
def reset_password(data: ResetIn):
    if not consume_code(data.email, "reset", data.code):
        raise HTTPException(400, "Invalid or expired code")
    with conn() as c:
        c.execute("UPDATE users SET password_hash=?, token_version=token_version+1, "
                  "failed_attempts=0, locked_until=NULL WHERE email=?",
                  (hash_pw(data.new_password), data.email))
    return {"message": "Password reset. Please log in."}


@app.post("/api/forgot-username")
def forgot_username(data: EmailIn, bg: BackgroundTasks):
    with conn() as c:
        user = c.execute("SELECT 1 FROM users WHERE email=?", (data.email,)).fetchone()
    if user and (code := issue_code(data.email, "username")):
        bg.add_task(send_email, data.email, "Your username recovery code",
                    f"Your code is {code}. It expires in {CODE_MINUTES} minutes.")
    return GENERIC


@app.post("/api/verify-username-code")
def verify_username_code(data: CodeIn):
    if not consume_code(data.email, "username", data.code):
        raise HTTPException(400, "Invalid or expired code")
    with conn() as c:
        row = c.execute("SELECT username FROM users WHERE email=?", (data.email,)).fetchone()
    return {"username": row["username"]}


@app.get("/api/users")
def list_users(_=Depends(require_roles("super_admin", "admin"))):
    with conn() as c:
        rows = c.execute("SELECT * FROM users ORDER BY id").fetchall()
    return [public(r) for r in rows]


@app.patch("/api/users/{user_id}/role")
def set_role(user_id: int, data: RoleIn, me=Depends(require_roles("super_admin"))):
    if user_id == me["id"]:
        raise HTTPException(400, "You cannot change your own role")
    with conn() as c:
        cur = c.execute("UPDATE users SET role=? WHERE id=?", (data.role, user_id))
    if cur.rowcount == 0:
        raise HTTPException(404, "User not found")
    return {"message": "Role updated"}
